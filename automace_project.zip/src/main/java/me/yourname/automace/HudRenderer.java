package me.yourname.automace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class HudRenderer {

    public static void render(DrawContext ctx, float tickDelta) {
        if (!AutoMaceMod.ENABLED) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        ctx.drawText(mc.textRenderer,
                "[AutoMace: ON]",
                5,
                5,
                0x00FF00,
                true);
    }
}
