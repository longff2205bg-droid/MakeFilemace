package me.yourname.automace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class AutoMaceLogic {

    private static final double MAX_RANGE = 4.0;
    private static final double FALL_SPEED = -0.2;
    private static final float AIM_SPEED = 10.0f;

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        if (!AutoMaceMod.ENABLED) return;

        // must be falling
        if (mc.player.isOnGround()) return;
        if (mc.player.getVelocity().y > FALL_SPEED) return;

        LivingEntity target = findTarget(mc);
        if (target == null) return;

        // aim
        aimAt(mc, target);

        int maceSlot = findMace(mc);
        if (maceSlot == -1) return;

        int currentSlot = mc.player.getInventory().selectedSlot;
        ItemStack currentItem = mc.player.getInventory().getStack(currentSlot);

        if (isSword(currentItem)) {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
        }

        mc.player.getInventory().selectedSlot = maceSlot;
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private static LivingEntity findTarget(MinecraftClient mc) {
        LivingEntity p = mc.world.getClosestEntity(
                PlayerEntity.class,
                e -> e.isAlive() && e != mc.player,
                mc.player,
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ(),
                mc.player.getBoundingBox().expand(MAX_RANGE)
        );
        if (p != null) return p;

        return mc.world.getClosestEntity(
                LivingEntity.class,
                e -> e.isAlive() && !(e instanceof PlayerEntity),
                mc.player,
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ(),
                mc.player.getBoundingBox().expand(MAX_RANGE)
        );
    }

    private static void aimAt(MinecraftClient mc, LivingEntity target) {
        Vec3d eyes = mc.player.getEyePos();
        Vec3d targetEyes = target.getEyePos();

        double dx = targetEyes.x - eyes.x;
        double dy = targetEyes.y - eyes.y;
        double dz = targetEyes.z - eyes.z;

        double distXZ = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, distXZ)));

        smoothRotate(mc, yaw, pitch);
    }

    private static void smoothRotate(MinecraftClient mc, float targetYaw, float targetPitch) {
        float curYaw = mc.player.getYaw();
        float curPitch = mc.player.getPitch();

        float yawDiff = wrap(targetYaw - curYaw);
        float pitchDiff = wrap(targetPitch - curPitch);

        mc.player.setYaw(curYaw + clamp(yawDiff, -AIM_SPEED, AIM_SPEED));
        mc.player.setPitch(curPitch + clamp(pitchDiff, -AIM_SPEED, AIM_SPEED));
    }

    private static int findMace(MinecraftClient mc) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.MACE) {
                return i;
            }
        }
        return -1;
    }

    private static boolean isSword(ItemStack stack) {
        return stack != null && stack.getItem().toString().toLowerCase().contains("sword");
    }

    private static float wrap(float v) {
        v %= 360;
        if (v >= 180) v -= 360;
        if (v < -180) v += 360;
        return v;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
