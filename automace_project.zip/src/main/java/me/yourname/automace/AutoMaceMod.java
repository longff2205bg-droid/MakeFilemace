package me.yourname.automace;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class AutoMaceMod implements ClientModInitializer {

    public static boolean ENABLED = false;

    @Override
    public void onInitializeClient() {
        Keybinds.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Keybinds.tick(client);
            if (ENABLED) {
                AutoMaceLogic.tick(client);
            }
        });

        HudRenderCallback.EVENT.register(HudRenderer::render);
    }
}
