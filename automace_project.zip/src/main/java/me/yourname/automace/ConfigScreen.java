package me.yourname.automace;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ConfigScreen extends Screen {

    protected ConfigScreen() {
        super(Text.literal("AutoMace Settings"));
    }

    @Override
    protected void init() {
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
