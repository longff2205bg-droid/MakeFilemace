package me.yourname.automace;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class Keybinds {

    private static KeyBinding TOGGLE;
    private static KeyBinding MENU;

    public static void register() {
        TOGGLE = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("Toggle AutoMace", GLFW.GLFW_KEY_B, "AutoMace")
        );
        MENU = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("AutoMace Menu", GLFW.GLFW_KEY_N, "AutoMace")
        );
    }

    public static void tick(MinecraftClient client) {
        while (TOGGLE.wasPressed()) {
            AutoMaceMod.ENABLED = !AutoMaceMod.ENABLED;
        }

        while (MENU.wasPressed()) {
            client.setScreen(new ConfigScreen());
        }
    }
}
