AutoMace Fabric mod (1.21.0) - demo project
-----------------------------------------
Contents:
- source in src/main/java/me/yourname/automace
- fabric.mod.json and automace.mixins.json in resources
- build.gradle and settings.gradle in project root

NOTES:
- This project does NOT include Gradle wrapper (gradlew) by default.
- To build:
  - Option A (recommended): run 'gradle wrapper' on your local machine to create the wrapper files, or use a host with Gradle installed.
  - Option B: Use GitHub template for Fabric example mod (has wrapper), then copy src and resources into it.
  - Option C: Use the Telegram build bot (it will try './gradlew' else 'gradle' if available).

Build command (if gradle available):
  gradle wrapper
  ./gradlew build

Output jar will be in build/libs/
